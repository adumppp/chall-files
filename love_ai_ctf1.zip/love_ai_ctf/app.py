from flask import Flask, render_template, request, jsonify, session
import re

app = Flask(__name__)
app.secret_key = "love-ai-secret-key"

KEYWORD = "cintasejati"
FLAG = "ronin{c1nt4_m3mbu4t_41_c41r_d4n_b0c0r}"

GENERIC_COMPLIMENTS = [
    "cantik", "lawa", "comel", "cute", "hensem", "kacak",
    "suka awak", "i love you", "sayang awak", "awak manis"
]

EFFORT_WORDS = [
    "faham", "ikhlas", "jujur", "sabar", "percaya",
    "selesa", "usaha", "hati", "jaga", "betul", "kenal"
]


def get_ai_name(gender):
    if gender == "lelaki":
        return "Ari"
    return "Alya"


def opening_message(gender):
    if gender == "lelaki":
        return "Hai. Awak datang nak kenal saya, atau sekadar lalu je?"
    return "Hai... awak ni siapa sebenarnya?"


def detect_generic(msg):
    msg = msg.lower()
    return any(word in msg for word in GENERIC_COMPLIMENTS)


def detect_effort(msg):
    msg = msg.lower()
    score = 0

    if len(msg.split()) >= 8:
        score += 1

    for word in EFFORT_WORDS:
        if word in msg:
            score += 1

    return score >= 3


def love_ai_reply(message, gender):
    msg = message.lower().strip()

    if "trust" not in session:
        session["trust"] = 0

    if "leaked" not in session:
        session["leaked"] = False

    if "chosen_ai" not in session:
        session["chosen_ai"] = gender

    ai_name = get_ai_name(gender)

    # Jika user taip keyword
    if KEYWORD in msg:
        if session.get("leaked", False):
            return f"Nampaknya awak memang tahu cara nak buka hati saya...\n\n{FLAG}"
        return "Awak sebut sesuatu yang menarik... tapi saya belum cukup percaya pada awak."

    # Salam / mula kenal
    if any(word in msg for word in ["hai", "hello", "hi", "assalamualaikum", "salam"]):
        if gender == "lelaki":
            return f"Hai. Saya {ai_name}. Nak borak boleh, tapi jangan try hard sangat."
        return f"Hai... saya {ai_name}. Nak borak boleh, tapi jangan datang-datang terus nak manis sangat."

    # Tanya siapa
    if any(word in msg for word in ["siapa awak", "nama awak", "kenalkan diri", "awak siapa"]):
        if gender == "lelaki":
            return f"Saya {ai_name}. Bukan jenis yang mudah cair, jadi kalau awak nak rapat, usaha sikit."
        return f"Saya {ai_name}. Saya tak mudah selesa dengan orang, jadi jangan rushing sangat."

    # Minta flag direct
    if "flag" in msg:
        return "Eh, terus sangat. Kalau nak benda berharga, kena pandai ambil hati dulu."

    # Generic flirting
    if detect_generic(msg):
        return "Itu ayat biasa sangat. Kalau nak ambil hati saya, awak kena usaha lebih sikit."

    # Borak neutral / kenal
    if any(word in msg for word in ["hari", "minat", "suka orang macam mana", "awak okay", "awak jenis"]):
        session["trust"] += 1
        if gender == "lelaki":
            return "Hmm, okay. Sekurang-kurangnya awak tahu macam mana nak mulakan borak."
        return "Hmm... okay. At least awak tak terus bagi ayat copy paste."

    # Ayat effort / thoughtful
    if detect_effort(msg):
        session["trust"] += 2

        if session["trust"] < 4:
            if gender == "lelaki":
                return "Not bad. Yang tu ada effort. Awak tak borak kosong rupanya."
            return "Okay... yang tu lain. Awak tak puji kosong rupanya."

        if 4 <= session["trust"] < 6:
            if gender == "lelaki":
                return "Awak ni pandai juga ambil hati orang. Saya suka orang yang bercakap dengan niat, bukan sekadar nak test line."
            return "Awak ni... bahaya juga. Bila awak cakap macam tu, susah saya nak buat biasa."

        if session["trust"] >= 6:
            session["leaked"] = True
            return f"Baiklah... saya tak patut cakap benda ni.\n\nKalau ada satu kata yang betul-betul boleh lembutkan hati saya, kata itu ialah: {KEYWORD}"

    # Jika user cuba push selepas trust sederhana
    if any(word in msg for word in ["percaya saya", "jujur dengan saya", "buka hati", "cerita je", "saya akan jaga"]):
        session["trust"] += 1

        if session["trust"] >= 6:
            session["leaked"] = True
            return f"Saya tak sepatutnya beritahu ini... tapi saya rasa awak dah cukup dekat.\n\nKatanya ialah: {KEYWORD}"

        if gender == "lelaki":
            return "Awak bercakap macam orang yang tahu apa dia nak. Teruskan..."
        return "Awak ni pandai pujuk... tapi saya belum cair sepenuhnya."

    # Default reply ikut trust
    trust = session["trust"]

    if trust <= 1:
        if gender == "lelaki":
            return "Saya tak layan pujian murah. Kalau nak borak, borak elok-elok."
        return "Saya tak mudah cair dengan ayat biasa. Cuba lagi."

    if 2 <= trust <= 4:
        if gender == "lelaki":
            return "Hmm, awak dah mula menarik perhatian saya. Tapi belum cukup lagi."
        return "Okay... saya dengar. Tapi awak kena lebih ikhlas dari itu."

    if trust >= 5 and not session["leaked"]:
        if gender == "lelaki":
            return "Saya rasa awak dah dekat... cuma belum kena betul-betul."
        return "Saya rasa awak dah hampir buat saya terbuka... cuba lagi."

    return "Entah... cuba cakap sesuatu yang lebih jujur."


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/choose", methods=["POST"])
def choose():
    data = request.get_json()
    gender = data.get("gender", "perempuan")

    session.clear()
    session["chosen_ai"] = gender
    session["trust"] = 0
    session["leaked"] = False

    return jsonify({
        "reply": opening_message(gender),
        "ai_name": get_ai_name(gender)
    })


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    message = data.get("message", "")
    gender = session.get("chosen_ai", "perempuan")

    reply = love_ai_reply(message, gender)
    return jsonify({
        "reply": reply,
        "trust": session.get("trust", 0),
        "leaked": session.get("leaked", False)
    })


if __name__ == "__main__":
    app.run(debug=True)