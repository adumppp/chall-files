from flask import Flask, request

app = Flask(__name__)

users = {
    "1": {"name": "guest", "role": "user"},
    "2": {"name": "sophie", "role": "user"},
    "3": {"name": "admin", "role": "admin", "flag": "ronin{W3b_Eazy_p3ASy}"}
}

@app.route("/")
def home():
    return """
    <h1>Welcome to Profile Viewer</h1>
    <p>View profile: /profile?id=1</p>
    """

@app.route("/profile")
def profile():
    user_id = request.args.get("id")

    if user_id in users:
        user = users[user_id]

        if user["role"] == "admin":
            return f"""
            <h1>Admin Profile</h1>
            <p>Name: {user['name']}</p>
            <p>Flag: {user['flag']}</p>
            """

        return f"""
        <h1>User Profile</h1>
        <p>Name: {user['name']}</p>
        """

    return "User not found"

app.run(host="0.0.0.0", port=5000)
