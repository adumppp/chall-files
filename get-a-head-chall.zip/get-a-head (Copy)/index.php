<?php
$method = $_SERVER['REQUEST_METHOD'] ?? '';

$color = "Red";
$bg = "red";

// Change color if POST
if ($method === "POST") {
    $color = "Blue";
    $bg = "blue";
}

// Hidden condition for HEAD request
if ($method === "HEAD") {
    header("flag: ronin{hidd3n_meth0d}");
    exit();
}
?>

<!doctype html>
<html>
<head>
    <title><?php echo $color; ?></title>

    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <style>
        body {
            background-color: <?php echo $bg; ?>;
        }
    </style>
</head>

<body>
<div class="container">
    <div class="row">

        <!-- Red Panel -->
        <div class="col-md-6">
            <div class="panel panel-primary" style="margin-top:50px">
                <div class="panel-heading">
                    <h3 class="panel-title" style="color:red">Red</h3>
                </div>
                <div class="panel-body">
                    <form action="index.php" method="GET">
                        <input type="submit" value="Choose Red" class="btn btn-danger"/>
                    </form>
                </div>
            </div>
        </div>

        <!-- Blue Panel -->
        <div class="col-md-6">
            <div class="panel panel-primary" style="margin-top:50px">
                <div class="panel-heading">
                    <h3 class="panel-title" style="color:blue">Blue</h3>
                </div>
                <div class="panel-body">
                    <form action="index.php" method="POST">
                        <input type="submit" value="Choose Blue" class="btn btn-primary"/>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
</body>
</html>
