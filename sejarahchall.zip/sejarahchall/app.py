from flask import Flask, request, render_template, session
import time

app = Flask(__name__)
app.secret_key = "melaka-secret-key-ctf"

SULTANS = {
    1: {"name": "Parameswara", "reign": "1400 – 1414"},
    2: {"name": "Sultan Megat Iskandar Shah", "reign": "1414 – 1424"},
    3: {"name": "Sultan Muhammad Shah", "reign": "1424 – 1444"},
    4: {"name": "Sultan Abu Syahid", "reign": "1444 – 1446"},
    5: {"name": "Sultan Muzaffar Shah", "reign": "1446 – 1459"},
    6: {"name": "Sultan Mansur Shah", "reign": "1459 – 1477"},
    7: {"name": "Sultan Alauddin Riayat Shah", "reign": "1477 – 1488"},
    8: {"name": "Sultan Mahmud Shah", "reign": "1488 – 1511"},
}

PUBLIC_LIST = [1, 2, 3, 5, 6, 7, 8]
FLAG = "ronin{f4ll_0f_m3l4k4_1511}"

# Simpan request log sementara ikut IP
request_log = {}

# Tetapan rate limit
RATE_LIMIT_COUNT = 12
RATE_LIMIT_WINDOW = 10  # saat


def is_rate_limited(ip):
    now = time.time()

    if ip not in request_log:
        request_log[ip] = []

    # Simpan request yang masih dalam window masa
    request_log[ip] = [t for t in request_log[ip] if now - t < RATE_LIMIT_WINDOW]

    # Tambah request baru
    request_log[ip].append(now)

    # Check limit
    return len(request_log[ip]) > RATE_LIMIT_COUNT


@app.before_request
def protect_from_bruteforce():
    ip = request.remote_addr

    # Abaikan static file dari rate limit
    if request.path.startswith("/static"):
        return

    if is_rate_limited(ip):
        return render_template("error.html", message="Too many archive requests. Slow down."), 429


@app.route("/")
def home():
    public_sultans = []
    for sid in PUBLIC_LIST:
        public_sultans.append({
            "id": sid,
            "name": SULTANS[sid]["name"],
            "reign": SULTANS[sid]["reign"]
        })
    return render_template("home.html", sultans=public_sultans)


@app.route("/profile")
def profile():
    pid = request.args.get("id", "").strip()

    # Lock flag page: mesti lawat id=8 dulu
    if pid == "1511":
        if not session.get("visited_8"):
            return render_template(
                "error.html",
                message="This archive record is locked. Trace the final royal record first."
            ), 403
        return render_template("flag.html", flag=FLAG)

    if pid.isdigit():
        pid = int(pid)

        if pid in SULTANS:
            s = SULTANS[pid]

            # Bila buka Sultan Mahmud Shah, unlock flag path
            if pid == 8:
                session["visited_8"] = True

            hint = ""
            if pid == 4:
                hint = "Some answers are not found in names, but in the years they leave behind."

            return render_template("profile.html", sid=pid, sultan=s, hint=hint)

    return render_template("error.html", message="Archive index out of range"), 404


if __name__ == "__main__":
    app.run(debug=True)