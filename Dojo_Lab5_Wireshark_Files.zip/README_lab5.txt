LAB 5 SYNTHETIC WIRESHARK TRAINING CAPTURE

Open emailpackets_lab5.pcap using Wireshark (File > Open).

Part 1: Look at TCP, DNS, HTTP, SMTP traffic. Filter tcp or dns.
Part 2: Apply display filter http, then dns. Open the HTTP GET request.
Part 3: Apply smtp. Find MAIL FROM in either of two SMTP sessions. Right-click a relevant packet > Follow > TCP Stream.
First SMTP stream contains the backup password clue: Hell0W0rld!
Second SMTP stream contains multipart email with Base64 attachment backup.zip. Recover attachment by saving the email message and opening it in an email client, or extract the Base64 attachment to backup.zip.
Use password Hell0W0rld! to open ZIP. backup.zip is also included separately for independent verification.

Note: The lab handout references backup.rar, but this self-contained synthetic exercise uses encrypted backup.zip instead. All network endpoints and messages are fictitious.
