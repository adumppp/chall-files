# Sejarah CTF challenge — Docker deployment

This organizer package contains the original Flask app, HTML and CSS unchanged, plus a Dockerfile, Compose configuration, pinned Python dependencies and regression tests. It needs Linux containers and Docker Compose v2. No database or persistent volume is needed.

## Start on a Linux server

```sh
unzip sejarahchall-docker.zip
cd sejarahchall-docker
docker compose config
docker compose up -d --build
docker compose ps
curl -f http://127.0.0.1:8000/static/style.css
```

Open http://127.0.0.1:8000 on the server. From your own computer, use an SSH tunnel:

```sh
ssh -L 8000:127.0.0.1:8000 YOUR_USER@YOUR_SERVER
```

Then open http://127.0.0.1:8000 locally. On Docker Desktop, select Linux containers and run the Compose commands from the extracted directory.

## Expose to contestants

For direct access on a dedicated CTF VM, copy `.env.example` to `.env`, set `BIND_ADDRESS=0.0.0.0`, and choose `PORT=8000` (or a free host port). Apply with `docker compose up -d`. Players use `http://YOUR_SERVER:8000`.

Restrict inbound access with your cloud firewall or Docker-aware host firewall to the intended CTF audience. Docker port publishing may bypass ordinary host firewall rules; verify from another machine. Use a separate VM from CTFd, production services and private infrastructure. Do not install credentials or mount host files or the Docker socket into this container. This package includes the flag and solution details: keep it organizer-only.

The Compose bridge is dedicated to this deployment but permits outbound traffic. On an untrusted public event server, enforce egress denial at the VM/network firewall, including private networks and cloud metadata endpoints, while allowing established replies. Container resource limits and dropped privileges are defense in depth, not a complete security boundary. Retain Docker's default seccomp and platform security profiles.

A TLS reverse proxy can forward to the localhost port, but the original application uses `request.remote_addr` and does not trust forwarded headers. Through a proxy or SSH tunnel all players may share its 12-requests-per-10-seconds quota. For unchanged behavior, use direct published access and verify the source addresses in the logs, or deploy one instance per team. Do not blindly trust user-supplied X-Forwarded-For. No ProxyFix middleware was added because that would change the challenge's behavior and trust boundary.

## Runtime and preserved challenge behavior

- Gunicorn listens on container port 8000 with exactly one synchronous worker and one thread. The rate limiter is a process-local dictionary, so multiple workers or replicas would change its behavior. Restarting resets the dictionary; cookies remain valid because the original signing key is unchanged.
- The app source still contains its original local `debug=True` launcher. Docker imports `app:app` through Gunicorn, so that launcher and the interactive debugger do not run. This deliberately avoids exposing a development debugger; the archive puzzle does not require it.
- Public records, the omitted record 4 and its HTML comment, record 8's session unlock, record 1511's flag, and the original hardcoded flag/signing key are preserved. The known-key cookie-forgery path also remains possible.
- The original rate limiter retains IP dictionary keys indefinitely. Memory is capped at 128 MiB; sufficiently many source IPs can still exhaust that cap and cause a restart. This limitation was preserved rather than rewriting challenge logic.
- The container runs as UID/GID 10001 with no Linux capabilities and no privilege escalation. Its filesystem is read-only under Compose; only a 16 MiB temporary filesystem is writable. CPU, process and log limits are configured.
- Health checks request the existing static stylesheet, which is exempt from the app rate limit. Docker marks failures unhealthy; Compose's restart policy only restarts exited processes, not merely unhealthy ones.

## Verify and operate

```sh
docker compose logs --tail=100 challenge
docker compose exec challenge id
docker compose exec challenge python -c "from pathlib import Path; Path('/app/write-test').touch()"
```

The last command should fail with a read-only filesystem error. To run the organizer regression tests against the built image without including tests in the image:

```sh
docker compose run --rm -T --no-deps challenge python - < tests/test_challenge.py
```

The tests cover the home page, hidden hint, locked and unlocked flag path, fresh-session isolation, invalid records, rate-limit threshold/expiry, static-file exemption, separate client IPs, and preserved signing-key behavior. They operate on an isolated in-process Flask client and do not affect the running service.

```sh
docker compose restart challenge   # reset in-memory throttling
docker compose down                # stop and remove containers/network
```

To deploy another team, copy this directory, select another host port in `.env`, and start with a unique project name, for example `docker compose -p sejarah-team2 up -d --build`. Keep each instance at one worker.

## Dockerfile without Compose

Compose is recommended because its security and resource restrictions are not embedded in the Dockerfile. Equivalent basic Linux launch:

```sh
docker build -t sejarahchall:local .
docker run -d --name sejarahchall --init --restart unless-stopped \
  -p 127.0.0.1:8000:8000 --read-only \
  --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m,mode=1777 \
  --cap-drop ALL --security-opt no-new-privileges:true \
  --pids-limit 64 --memory 128m --cpus 0.5 \
  --log-opt max-size=10m --log-opt max-file=3 sejarahchall:local
```

Python packages are version-pinned. The Python base tag can receive updates; record/pin its resolved digest if you require repeatable event builds. Build and smoke-test before the event, and retain the tested image.

## Validation status

The original uploaded ZIP was retrieved from the referenced conversation. All original application files were verified byte-for-byte against it. Four regression tests passed locally on Windows with Python 3.14 and the pinned dependencies. Docker is unavailable in the preparation environment: Linux image build, Gunicorn startup, Compose validation and runtime confinement must still be checked on the deployment host. The image uses Python 3.13.

## References

- Docker Compose service controls: https://docs.docker.com/reference/compose-file/services/
- Docker networking: https://docs.docker.com/compose/how-tos/networking/
- Flask package: https://pypi.org/project/Flask/
- Gunicorn package: https://pypi.org/project/gunicorn/
