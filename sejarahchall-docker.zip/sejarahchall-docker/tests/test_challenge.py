"""Organizer-only regression checks; no live service required."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app as challenge


class ChallengeTests(unittest.TestCase):
    def setUp(self):
        challenge.request_log.clear()
        self.client = challenge.app.test_client()

    def test_original_solve_path(self):
        home = self.client.get('/')
        self.assertEqual(home.status_code, 200)
        self.assertNotIn(b'/profile?id=4', home.data)
        self.assertEqual(self.client.get('/profile?id=1511').status_code, 403)
        hidden = self.client.get('/profile?id=4')
        self.assertEqual(hidden.status_code, 200)
        self.assertIn(b'<!-- Some answers', hidden.data)
        self.assertEqual(self.client.get('/profile?id=8').status_code, 200)
        flag = self.client.get('/profile?id=1511')
        self.assertEqual(flag.status_code, 200)
        self.assertIn(challenge.FLAG.encode(), flag.data)
        self.assertEqual(challenge.app.test_client().get('/profile?id=1511').status_code, 403)

    def test_invalid_ids(self):
        for value in ('', 'abc', '9', '-1'):
            self.assertEqual(self.client.get('/profile?id=' + value).status_code, 404)

    def test_rate_limit_and_expiry(self):
        with patch('app.time.time', return_value=1000):
            for _ in range(12):
                self.assertEqual(self.client.get('/').status_code, 200)
            self.assertEqual(self.client.get('/').status_code, 429)
            with self.client.get('/static/style.css') as static:
                self.assertEqual(static.status_code, 200)
            self.assertEqual(self.client.get('/', environ_overrides={'REMOTE_ADDR': '192.0.2.2'}).status_code, 200)
        with patch('app.time.time', return_value=1011):
            self.assertEqual(self.client.get('/').status_code, 200)

    def test_original_signing_key_behavior(self):
        serializer = challenge.app.session_interface.get_signing_serializer(challenge.app)
        cookie = serializer.dumps({'visited_8': True})
        self.client.set_cookie('session', cookie)
        response = self.client.get('/profile?id=1511')
        self.assertIn(challenge.FLAG.encode(), response.data)


if __name__ == '__main__':
    unittest.main(verbosity=2)
