#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void setup(void) {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
    alarm(60);
}

void ronin_call(void) {
    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        puts("The scroll is missing.");
        exit(1);
    }

    char flag[128];
    if (!fgets(flag, sizeof(flag), f)) {
        puts("The ronin could not read the scroll.");
        fclose(f);
        exit(1);
    }

    puts("\n[+] The Call of the Ronin has been answered.");
    puts(flag);

    fclose(f);
    exit(0);
}

void dojo_trial(void) {
    char oath[64];

    puts("======================================");
    puts("        THE CALL OF THE RONIN         ");
    puts("======================================");
    puts("Speak your oath, wanderer:");

    read(0, oath, 200);

    puts("Your words echo through the dojo...");
}

int main(void) {
    setup();
    dojo_trial();
    return 0;
}
